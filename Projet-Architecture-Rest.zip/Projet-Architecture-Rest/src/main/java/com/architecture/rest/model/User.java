package com.architecture.rest.model;


import org.springframework.data.jpa.domain.support.AuditingEntityListener;



import javax.persistence.*;
import javax.validation.constraints.NotNull;


@Entity
@Table(name = "users")
@EntityListeners(AuditingEntityListener.class)

public class User {

	@GeneratedValue(strategy = GenerationType.AUTO)
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Id
	@Column(name = "id")
	private Long id;
	
	//@Column(nullable=false)
	@NotNull
	private Long username;
	
	@NotNull
	private String statut;
	
	@NotNull
	private String firstName;
	
	@NotNull
	private String lastName;
	
	@NotNull
	private String email;
	
	@NotNull
	private String password;
	
	// Default constructor require by JPA
	public User() {}
	
	public User(String firstName, String lastName, String statut, String mail, String password, Long username) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.statut = statut;
		this.email = mail;
		this.password = password;
		this.username = username;
	}
	
	//Getters & Setters
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	public Long getUsername() {
		return username;
	}
	public void setUsername(Long username) {
		this.username = username;
	}
	public String getStatut() {
		return statut;
	}
	public void setStatut(String statut) {
		this.statut = statut;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "User [username=" + username + ", statut=" + statut + ", firstName=" + firstName + ", lastName="
				+ lastName + ", email=" + email + ", password=" + password + "]";
	}

	//@Override
	//public String toString() {
		//return "User [firstName=" + firstName + ", lastName=" + lastName + "]";
	//}
	
	
}
