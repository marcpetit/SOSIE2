package com.architecture.rest.service;

import com.architecture.rest.data.UserView;
import com.architecture.rest.repository.UserRepository;
import com.architecture.rest.model.User;

public interface UserService {
	public User parseUserViewToUser(UserView userview);  
	public UserView parseUserToUserView(User userentity);
	public void saveUser(User user, UserRepository userRepository);
	public void deleteUser(User user, UserRepository userRepository);
	public User checkUser(User user, UserRepository userRepository);
	public User GetUserById(Long i, UserRepository userRepository);
}
