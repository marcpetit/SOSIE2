package com.architecture.rest.service;

import com.architecture.rest.repository.UserRepository;

import com.architecture.rest.data.UserView;
import com.architecture.rest.model.User;

public class UserServiceImpl implements UserService {

	@Override
	public User parseUserViewToUser(UserView userview) {

		User user = new User();
		user.setFirstName(userview.getFirstName());
		user.setLastName(userview.getLastName());
		user.setUsername(userview.getUsername());
		user.setEmail(userview.getEmail());
		user.setPassword(userview.getPassword());
		user.setStatut(userview.getStatut());

		return user;
	}

	@Override
	public void saveUser(User userEntity, UserRepository userRepository) {
		userRepository.save(userEntity);
	}

	@Override
	public User checkUser(User userEntity, UserRepository userRepository) {
		User user = new User();
		user = userRepository.findOne(userEntity.getUsername());
		return user;
	}

	@Override
	public User GetUserById(Long id, UserRepository userRepository) {
		return userRepository.findOne(id);
		
	}
	

	@Override
	public UserView parseUserToUserView(User userentity) {

		UserView userview = new UserView();
		userview.setFirstName(userentity.getFirstName());
		userview.setLastName(userentity.getLastName());
		userview.setUsername(userentity.getUsername());
		userview.setEmail(userentity.getEmail());
		userview.setPassword(userentity.getPassword());
		userview.setStatut(userentity.getStatut());

		return userview;
	}

	@Override
	public void deleteUser(User userEntity, UserRepository userRepository) {
		userRepository.delete(userEntity);
	}

}
