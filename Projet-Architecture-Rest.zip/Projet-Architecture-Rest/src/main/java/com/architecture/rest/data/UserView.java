package com.architecture.rest.data;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

//import java.io.File;

//import javax.persistence.Column;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.architecture.rest.data.UserView;

public class UserView {
public UserView() {
		
	}
	
	public UserView(UserView usr1, UserView usr2) {
		usr1.firstName = usr2.firstName;
		usr1.lastName = usr2.lastName;
		usr1.statut = usr2.statut;
		usr1.email = usr2.email;
		usr1.password = usr2.password;
		
	}

	/*public UserView(String firstName, String lastName, String statut, String mail, String password, File photo, Long username) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.statut = statut;
		this.email = mail;
		this.username = username;
		this.password = password;
		
	}*/
	
	public UserView(Long username, String statut, String firstName, String lastName, String email, String password) {
		super();
		this.username = username;
		this.statut = statut;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
	}
	
	@GeneratedValue(strategy = GenerationType.AUTO)
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Id
	private Long id;
	
	@NotNull
	private Long username;
	
	@NotNull
	private String statut;
	@NotNull
	private String firstName;
	@NotNull
	private String lastName;
	
	@NotNull
	private String email;
	
	@NotNull
	private String password;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getUsername() {
		return username;
	}

	public void setUsername(Long username) {
		this.username = username;
	}

	public String getStatut() {
		return statut;
	}

	public void setStatut(String statut) {
		this.statut = statut;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	

	@Override
	public String toString() {
		return "UserView [username=" + username + ", statut=" + statut + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", email=" + email + ", password=" + password + "]";
	}
	
	
	
	
}
