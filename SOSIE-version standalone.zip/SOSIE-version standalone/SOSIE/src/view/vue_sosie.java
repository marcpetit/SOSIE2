package view;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.InputMismatchException;
import java.util.Locale;
import java.util.Scanner;

import bdd.JDBC;
import sosie_class.Stage;
import sosie_class.UniteEnseignementEntity;
import sosie_class.UserEntity;

public class vue_sosie {
	private UserEntity Utilisateur;
	private Stage stage;
	
	public vue_sosie(){
		Utilisateur=new UserEntity();
		stage=new Stage();
	}
	
	public void controlleur(String route){
		String redirection;
		if(route=="home") {
			redirection=home();
			controlleur(redirection);
		}
		if(route=="Create an account") {
			redirection=createAccount();
			controlleur(redirection);
		}
		if(route=="Sign In") {
			redirection=signIn();
			controlleur(redirection);			
		}
		if(route=="home user") {
			redirection=home_user();
			controlleur(redirection);
		}
		
		if(route=="Editer profil") {
			redirection=update_profil();
			controlleur(redirection);
		}
		if(route=="Stage") {
			redirection=stage();
			controlleur(redirection);
		}
		if(route=="Supprimer") {
			redirection=supprimer();
			controlleur(redirection);
		}
		if(route=="UE") {
			redirection=ue();
			controlleur(redirection);
		}
		if(route=="Deconnexion") {
			redirection=deconnexion();
			controlleur(redirection);
		}
		if(route=="Creer un stage") {
			redirection=createStage();
			controlleur(redirection);
		}
		if(route=="Editer stage") {
			redirection=update_stage();
			controlleur(redirection);
		}
		if(route=="Ajout UE") {
			redirection=ajoutUe();
			controlleur(redirection);
		}
		if(route=="Del UE") {
			redirection=delUe();
			controlleur(redirection);
		}
		if(route=="Edit UE") {
			redirection=editUe();
			controlleur(redirection);
		}
	}
	public String home() {
		int saisie=0;
		Scanner sc=new Scanner(System.in);
		System.out.print("\n\nInstitut des Sciences et Techniques des Yvelines");
	
		do {
			System.out.print("\n\n-Create an account (touche 1)\n-Sign in (touche 2)\n");
			System.out.print("-Selection:");
			try{                                              
				saisie=sc.nextInt();
			}                                            
			catch(InputMismatchException e){
			
				//System.out.println("\nErreur entier attendu!!!\nFermeture du programme");
				//System.exit(0);
				System.out.println("\nErreur entier attendu!!!\n");
				return "home";
			}

		}while((saisie !=1) && (saisie!=2));	
		
		if(saisie==1) {
			return "Create an account";
		}
		else {
			return "Sign In";
		}
	}
	
	public String signIn(){
		int login=0;
		boolean test;
		String mdp="null";
		
		Scanner sc=new Scanner(System.in);
		Scanner sc2=new Scanner(System.in);
		System.out.print("\nSIGN IN\nEntrer le login:");
		try{   
			login=sc.nextInt();
		}                                            
		catch(InputMismatchException e){
		
			//System.out.println("\nErreur entier attendu!!!\nFermeture du programme");
			//System.exit(0);
			System.out.println("\nErreur entier attendu!!!\n");
			return "Sign In";
		}
		
		System.out.print("\nEntrer le mot de passe:");
		mdp=sc2.nextLine();
		
		//v�rification login et mdp
		JDBC Sosie=new JDBC();
		test=Sosie.verifUser(login,mdp);
		
		if(test) {
			Utilisateur.setUsername(login);
			Utilisateur.setPassword(mdp);
			return "home user";
		}
		else {
			System.out.print("Login ou mot de passe non valide");
			return "home";
		}
	}
	
	public String createAccount() {
		Scanner sc=new Scanner(System.in);
		Scanner sc2=new Scanner(System.in);
		Scanner sc3=new Scanner(System.in);
		Scanner sc4=new Scanner(System.in);
		Scanner sc5=new Scanner(System.in);
		Scanner sc6=new Scanner(System.in);
		
		String firstName;
		String lastName;
		String mail;
		int status=0;
		String statut="Student";
		int login=0;
		String password;
		
		System.out.print("\n\nINSCRIPTION");
		System.out.print("\nFirstName:");
		firstName=sc.nextLine();
		System.out.print("LastName:");
		lastName=sc2.nextLine();
		System.out.print("Mail:");
		mail=sc3.nextLine();
		
		do {
			System.out.print("Student(touche 1),Teacher(touche 2),Administrator(touche 3):");
			try{   
				status=sc4.nextInt();
			}                                            
			catch(InputMismatchException e){
		
				/*System.out.println("\nErreur entier attendu!!!\nFermeture du programme");
				System.exit(0);*/
				System.out.println("\nErreur entier attendu!!!\n");
				return "Create an account";
			}
		}while(status!=1 && status!=2 && status!=3);
		
		if(status==1) {
			statut="Student";
		}
		if(status==2) {
			statut="teacher";
		}
		if(status==3) {
			statut="Administrator";
		}
		
		System.out.print("Login (number):");
		
		try{   
			login=sc5.nextInt();
		}                                            
		catch(InputMismatchException e){
	
			System.out.println("\nErreur entier attendu!!!\n");
			return "Create an account";
		}
		
		lastName=sc5.nextLine();
		System.out.print("Password:");
		password=sc6.nextLine();
		
		System.out.println("\nInformations enregistr�es !!");
		JDBC Sosie=new JDBC();
		Sosie.newAccount(firstName,lastName,mail,statut,login,password);
		
		return "home";
	}
	
	public String home_user() {
		int saisie=0;
		Scanner sc=new Scanner(System.in);
		System.out.print("\nBienvenue:");
		JDBC Sosie=new JDBC();
		Utilisateur=Sosie.RecupInfoUser(Utilisateur.getUsername(), Utilisateur.getPassword());
		System.out.print(Utilisateur.getFirstName()+" "+Utilisateur.getLastName());
		System.out.print("\n\nfirstName:"+Utilisateur.getFirstName());
		System.out.print("\nlastName:"+Utilisateur.getLastName());
		System.out.print("\nMail:"+Utilisateur.getMail());
		System.out.print("\nStatut:"+Utilisateur.getStatut());
		System.out.print("\nIdentifiant:"+Utilisateur.getUsername());
		System.out.print("\nPassword:"+Utilisateur.getPassword());
		
		do {
			System.out.print("\n\n-Editer profil(touche 1)\n-Stage(touche 2)\n-Supprimer(touche 3)\n-Onglet Unit� d'enseignement(touche 4)\n-Deconnexion(touche 5)\n");
			System.out.print("-Selection:");
			try{                                              
				saisie=sc.nextInt();
			}                                            
			catch(InputMismatchException e){
			
				/*System.out.println("\nErreur entier attendu!!!\nFermeture du programme");
				System.exit(0);*/
				System.out.println("\nErreur entier attendu!!!\n");
				return "home user";
			}
		}while((saisie !=1) && (saisie!=2) && (saisie!=3) && (saisie!=4) && (saisie!=5));
		
		if(saisie==1) {
			return "Editer profil";
		}
		if(saisie==2) {
			return "Stage";
		}
		if(saisie==3) {
			return "Supprimer";
		}
		if(saisie==4) {
			return "UE";
		}
		else {
			return "Deconnexion";
		}
	}
	
	public String update_profil() {
		JDBC Sosie=new JDBC();
		int saisie=0;
		String saisie2="";
		int saisie3=0;
		Scanner sc=new Scanner(System.in);
		Scanner sc2=new Scanner(System.in);
		do {
			System.out.print("\n\nEDIT PROFILE\nQuel champ souhaitez vous modifier?");
			System.out.print("\nfirstName:"+Utilisateur.getFirstName()+"(touche 1)");
			System.out.print("\nlastName:"+Utilisateur.getLastName()+"(touche 2)");
			System.out.print("\nMail:"+Utilisateur.getMail()+"(touche 3)");
			System.out.print("\nStatut:"+Utilisateur.getStatut()+"(touche 4)");
			System.out.print("\nPassword:"+Utilisateur.getPassword()+"(touche 5)");
			System.out.print("\nDeconnexion(touche 6)");
			System.out.print("\nVotre choix:");
			try{                                              
				saisie=sc.nextInt();
			}                                            
			catch(InputMismatchException e){
			
				/*System.out.println("\nErreur entier attendu!!!\nFermeture du programme");
				System.exit(0);*/
				System.out.println("\nErreur entier attendu!!!\n");
				return "Editer profil";
			}
		}while((saisie !=1) && (saisie!=2) && (saisie!=3) && (saisie!=4) && (saisie!=5)&& (saisie!=6));
	
		if(saisie==1) {
			System.out.print("\nNew firstName:");
			saisie2=sc2.nextLine();
			Utilisateur.setFirstName(saisie2);
		}
		if(saisie==2) {
			System.out.print("\nNew lastName:");
			saisie2=sc2.nextLine();
			Utilisateur.setLastName(saisie2);
		}
		if(saisie==3) {
			System.out.print("\nNew Mail:");
			saisie2=sc2.nextLine();
			Utilisateur.setMail(saisie2);
		}
		if(saisie==4) {
			do {
				System.out.print("\nNew Statut=>Student(touche 1),Teacher(touche 2),Administrator(touche 3):");
				try{   
					saisie3=sc2.nextInt();
				}                                            
				catch(InputMismatchException e){
			
					/*System.out.println("\nErreur entier attendu!!!\nFermeture du programme");
					System.exit(0);*/
					System.out.println("\nErreur entier attendu!!!\n");
					return "Editer profil";
				}
			}while(saisie3!=1 && saisie3!=2 && saisie3!=3);
			
			if(saisie3==1) {
				saisie2="Student";
			}
			if(saisie3==2) {
				saisie2="teacher";
			}
			if(saisie3==3) {
				saisie2="Administrator";
			}
			Utilisateur.setStatut(saisie2);
			
		}
		if(saisie==5) {
			System.out.print("\nNew Password:");
			saisie2=sc2.nextLine();
			Utilisateur.setPassword(saisie2);
		}
		
		if(saisie==6) {
			return "Deconnexion";
		}
		
		Sosie.modifInfoUser(Utilisateur.getUsername(),Utilisateur.getFirstName(),Utilisateur.getLastName(),Utilisateur.getMail(),Utilisateur.getStatut(),Utilisateur.getPassword());
		
		return "home user";
	}
	
	public String stage() {
		int saisie=0;
		Scanner sc=new Scanner(System.in);
		boolean test;
		JDBC Sosie=new JDBC();
		System.out.print("\n\nGestion de stage de "+Utilisateur.getFirstName()+" "+Utilisateur.getLastName());
		test=Sosie.RechercheStageUser(Utilisateur.getUsername());
		
		if(test) {
			stage=Sosie.RecupInfoStage(Utilisateur.getUsername());
			System.out.print("\nSujet de stage : "+stage.getSujet());
			System.out.print("\nEntreprise : "+stage.getNomEntreprise());
			System.out.print("\nDate de d�but :"+stage.getDateDebut());
			System.out.print("\nDate de fin :"+stage.getDateFin());
			System.out.print("\nEnseignant r�f�rent :"+stage.getEnseignantReferant().getUsername());
			
			do {
				System.out.print("\n\n-Editer un stage (touche 1)\n-Retour � l'accueil(touche 2)");
				System.out.print("\n-Selection:");
				try{                                              
					saisie=sc.nextInt();
				}                                            
				catch(InputMismatchException e){
				
					/*System.out.println("\nErreur entier attendu!!!\nFermeture du programme");
					System.exit(0);*/
					System.out.println("\nErreur entier attendu!!!\n");
					return "Stage";
				}

			}while((saisie !=1) && (saisie!=2));	
			
			if(saisie==1) {
				return "Editer stage";
			}
			else {
				return "home user";
			}
		}
		else {
			System.out.print("\nIl n'y a pas de stage � consulter");	
			do {
				System.out.print("\n-Cr�er un stage (touche 1)\n-Retour � l'accueil(touche 2)");
				System.out.print("\n-Selection:");
				try{                                              
					saisie=sc.nextInt();
				}                                            
				catch(InputMismatchException e){
				
					/*System.out.println("\nErreur entier attendu!!!\nFermeture du programme");
					System.exit(0);*/
					System.out.println("\nErreur entier attendu!!!\n");
					return "Editer profil";
				}

			}while((saisie !=1) && (saisie!=2));	
			
			if(saisie==1) {
				return "Creer un stage";
			}
			else {
				return "home user";
			}
			
		}
	}
	
	public String supprimer() {
		JDBC Sosie=new JDBC();
		Sosie.suppInfoUser(Utilisateur.getUsername());
		return "Deconnexion";
	}
	
	public String ue() {
		JDBC Sosie=new JDBC();
		int saisie=0;
		ResultSet bd = null;
		Scanner sc=new Scanner(System.in);
		System.out.print("\n\nUnites d'enseignement");
		
		bd=Sosie.RecupInfoue();
	    try {
			while(bd.next())  //on recup�re les caracteristiques ligne par ligne
			{
				System.out.print("\n\nIdentifiant:"+bd.getInt("ue.identifiant"));
				System.out.print("\nNom:"+bd.getString("ue.nom"));
				System.out.print("\nResponsable:"+bd.getString("user.first_name")+" "+bd.getString("user.last_name"));
				System.out.print("\nDescription:"+bd.getString("ue.description"));
			 }
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		
		
		do {
			System.out.print("\n\n-Ajouter/Supprimer/Editer une unit� d'enseignement(touche 1/2/3)\n-Retour profil(touche 4)\n-Deconnexion(touche5)\n");
			System.out.print("-Selection:");
			try{                                              
				saisie=sc.nextInt();
			}                                            
			catch(InputMismatchException e){
			
				/*System.out.println("\nErreur entier attendu!!!\nFermeture du programme");
				System.exit(0);*/
				System.out.println("\nErreur entier attendu!!!\n");
				return "UE";
			}

		}while((saisie !=1) && (saisie!=2)&& (saisie!=3)&& (saisie!=4)&& (saisie!=5));	
		
		if(saisie==1) {
			return "Ajout UE";
		}
		else if(saisie==2) {
			return "Del UE";
		}
		else if(saisie==3) {
			return "Edit UE";
		}
		else if(saisie==4) {
			return "home user";
		}
		else {
			return "Deconnexion";
		}
	}
	public String deconnexion() {
		Utilisateur.setFirstName("");
		Utilisateur.setLastName("");
		Utilisateur.setMail("");
		Utilisateur.setStatut("");
		Utilisateur.setUsername(0);
		Utilisateur.setPassword("");
		return "home";
	}
	public String createStage() {
		Scanner sc=new Scanner(System.in);
		Scanner sc2=new Scanner(System.in);
		Scanner sc3=new Scanner(System.in);
		Scanner sc4=new Scanner(System.in);
		Scanner sc5=new Scanner(System.in);
		Scanner sc6=new Scanner(System.in);
		
		String sujet;
		String entreprise;
		String date_debut;
		String date_fin;
		int id_enseignant_referant = 0;
		
		System.out.print("\n\nGestion de stage de "+Utilisateur.getFirstName()+" "+Utilisateur.getLastName());
		System.out.print("\nSujet:");
		sujet=sc.nextLine();
		System.out.print("Entreprise:");
		entreprise=sc2.nextLine();
		System.out.print("Date de d�but(AAAA-MM-JJ) :");
		date_debut=sc3.nextLine();
		System.out.print("Date de fin(AAAA-MM-JJ) :");
		date_fin=sc4.nextLine();
		System.out.print("ID Enseignant referant:");
		try{   
			id_enseignant_referant=sc5.nextInt();
		}                                            
		catch(InputMismatchException e){
		
				/*System.out.println("\nErreur entier attendu!!!\nFermeture du programme");
				System.exit(0);*/
				System.out.println("\nErreur entier attendu!!!\n");
				return "Creer un stage";
		}
		
		JDBC Sosie=new JDBC();
		Sosie.newStage(sujet,entreprise,date_debut,date_fin,id_enseignant_referant,Utilisateur.getUsername());
		
		System.out.println("\nInformations enregistr�es !!");
		return "Stage";
	}
	public String update_stage() {
		JDBC Sosie=new JDBC();
		int saisie=0;
		String saisie2="";
		int saisie3=0;
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date saisie4=null;
		Scanner sc=new Scanner(System.in);
		Scanner sc2=new Scanner(System.in);
		do {
			System.out.print("\n\nEDIT Stage\nQuel champ souhaitez vous modifier?");
			System.out.print("\nSujet de stage : "+stage.getSujet()+"(touche 1)");
			System.out.print("\nEntreprise : "+stage.getNomEntreprise()+"(touche 2)");
			System.out.print("\nDate de d�but :"+stage.getDateDebut()+"(touche 3)");
			System.out.print("\nDate de fin :"+stage.getDateFin()+"(touche 4)");
			System.out.print("\nEnseignant r�f�rent :"+stage.getEnseignantReferant().getUsername()+"(touche 5)");
			System.out.print("\nConsulter stage(touche 6)");
			System.out.print("\nVotre choix:");
			
			try{                                              
				saisie=sc.nextInt();
			}                                            
			catch(InputMismatchException e){
			
				/*System.out.println("\nErreur entier attendu!!!\nFermeture du programme");
				System.exit(0);*/
				System.out.println("\nErreur entier attendu!!!\n");
				return "Editer stage";
			}
		}while((saisie !=1) && (saisie!=2) && (saisie!=3) && (saisie!=4) && (saisie!=5)&& (saisie!=6));
	
		if(saisie==1) {
			System.out.print("\nSujet de stage:");
			saisie2=sc2.nextLine();
			stage.setSujet(saisie2);
		}
		if(saisie==2) {
			System.out.print("\nEntreprise:");
			saisie2=sc2.nextLine();
			stage.setNomEntreprise(saisie2);
		}	
		if(saisie==3) {
			System.out.print("\nDate de d�but:(AAAA-MM-JJ)");
			saisie2=sc2.nextLine();
			try {
				saisie4 = format.parse(saisie2);
				
				 /*System.out.println(saisie4);
		         System.out.println(format.format(saisie4));
		         System.out.println(saisie4);*/
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				System.out.println("Mauvais format de date!!!\nFermeture du programme\n");
				System.exit(0); 
			}
			stage.setDateDebut(saisie4);
		}
		
		if(saisie==4) {
			System.out.print("\nDate de fin:(AAAA-MM-JJ)");
			saisie2=sc2.nextLine();
			try {
				saisie4 = (Date) format.parse(saisie2);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				System.out.println("Mauvais format de date!!!\nFermeture du programme\n");
				System.exit(0); 
			}
			stage.setDateFin(saisie4);
		}
		
		if(saisie==5) {
				System.out.print("\nEnseignant r�f�rent:");
				try{   
					saisie3=sc2.nextInt();
				}                                            
				catch(InputMismatchException e){
			
					/*System.out.println("\nErreur entier attendu!!!\nFermeture du programme");
					System.exit(0);*/
					System.out.println("\nErreur entier attendu!!!\n");
					return "Editer stage";
				}
				stage.getEnseignantReferant().setUsername(saisie3);
		}
		
		if(saisie==6) {
			return "Stage";
		}
	
			
		//System.out.print("\nEnseignant r�f�rent :"+stage.getEnseignantReferant().getUsername()+"(touche 5)");
		Sosie.modifInfoStage(stage.getIdStage(),stage.getDateDebut(),stage.getDateFin(),stage.getNomEntreprise(),stage.getSujet(),Utilisateur.getUsername(),stage.getEnseignantReferant().getUsername());
		
		return "Stage";
	}
	
	public String ajoutUe() {
		Scanner sc=new Scanner(System.in);
		Scanner sc2=new Scanner(System.in);
		Scanner sc3=new Scanner(System.in);
		Scanner sc4=new Scanner(System.in);
		Scanner sc5=new Scanner(System.in);
		Scanner sc6=new Scanner(System.in);
		
		String description;
		String nom;
		String first_name;
		String last_name;
		int identifiant = 0;
		
		System.out.print("\n\nUnite d'Enseignement");
		System.out.print("\nIdentifiant:");
		try{   
			identifiant=sc.nextInt();
		}                                            
		catch(InputMismatchException e){
		
				/*System.out.println("\nErreur entier attendu!!!\nFermeture du programme");
				System.exit(0);*/
			System.out.println("\nErreur entier attendu!!!\n");
			return "Ajout UE";
		}
		
		System.out.print("Nom:");
		nom=sc2.nextLine();
		System.out.print("Enseignant Responsable (pr�nom):");
		first_name=sc3.nextLine();
		System.out.print("Enseignant Responsable (nom):");
		last_name=sc4.nextLine();
		System.out.print("Description:");
		description=sc5.nextLine();
		
		JDBC Sosie=new JDBC();
		Sosie.addUe(description,nom,first_name,last_name,identifiant);
		return "UE";
	}
	public String delUe() {
		JDBC Sosie=new JDBC();
		int saisie=0;
		Scanner sc=new Scanner(System.in);
		
		System.out.print("\nIdentifiant de l'Unit� d'enseignement � supprimer\n-Selection:");
		try{                                              
			saisie=sc.nextInt();
		}                                            
		catch(InputMismatchException e){
		
			/*System.out.println("\nErreur entier attendu!!!\nFermeture du programme");
			System.exit(0);*/
			System.out.println("\nErreur entier attendu!!!\n");
			return "Del UE";
		}	
		Sosie.suppUe(saisie);
		return "UE";
	}
	
	public String editUe() {
		JDBC Sosie=new JDBC();
		int saisie=0;
		int saisie4=0;
		int test=0;
		String saisie2="";
		String saisie5="";
		int saisie3=0;
		int idTeacher=0;
		ResultSet bd = null;
		Scanner sc=new Scanner(System.in);
		Scanner sc2=new Scanner(System.in);
		Scanner sc3=new Scanner(System.in);
		
		/////////////
		System.out.print("\n\nEDIT Unite d'Enseignement\nIdentifiant de l'unit� d'enseignement � modifier?");
		try{                                              
			saisie4=sc.nextInt();
		}                                            
		catch(InputMismatchException e){
		
			/*System.out.println("\nErreur entier attendu!!!\nFermeture du programme");
			System.exit(0);*/
			System.out.println("\nErreur entier attendu!!!\n");
			return "Edit UE";
			
		}
		bd=Sosie.RecupInfoue();
	    try {
			while(bd.next())  //on recup�re les caracteristiques ligne par ligne
			{
				if(bd.getInt("ue.identifiant")==saisie4) {
				System.out.print("\nIdentifiant:"+bd.getInt("ue.identifiant"));
				System.out.print("\nNom:"+bd.getString("ue.nom"));
				System.out.print("\nResponsable:"+bd.getString("user.first_name")+" "+bd.getString("user.last_name"));
				System.out.print("\nDescription:"+bd.getString("ue.description"));
				test=1;
				}
			 }
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		////////////
		if(test==1) {
			do {
				System.out.print("\n\nModification=> Identifiant(touche1),Nom(touche2),Responsable(touche3),Description(touche4)");
			try{                                              
				saisie=sc.nextInt();
			}                                            
			catch(InputMismatchException e){
			
				/*System.out.println("\nErreur entier attendu!!!\nFermeture du programme");
				System.exit(0);*/
				System.out.println("\nErreur entier attendu!!!\n");
				return "Edit UE";
			}
		}while((saisie !=1) && (saisie!=2) && (saisie!=3) && (saisie!=4));
	
		if(saisie==1) {
			System.out.print("\nIdentifiant:");
			saisie3=sc2.nextInt();
			Sosie.modifInfoStage2("identifiant",saisie3,saisie4);
			//saisie4
		}
		if(saisie==2) {
			System.out.print("\nNom:");
			saisie2=sc2.nextLine();
			Sosie.modifInfoStage1("nom",saisie2,saisie4);
		}
		if(saisie==3) {
			System.out.print("\nResponsable Prenom:");
			saisie2=sc2.nextLine();
			System.out.print("\nResponsable Nom:");
			saisie5=sc3.nextLine();
			idTeacher=Sosie.idUser(saisie2,saisie5);
			Sosie.modifInfoStage2("enseignant_responsable",idTeacher,saisie4);
		}
		if(saisie==4) {
			System.out.print("\nDescription:");
			saisie2=sc2.nextLine();
			Sosie.modifInfoStage1("description",saisie2,saisie4);
		}
		return "UE";
		
		}
		else {
			System.out.println("\nL'unit� d'enseignement n'existe pas!!");
			return "UE";
		}
	}
}
