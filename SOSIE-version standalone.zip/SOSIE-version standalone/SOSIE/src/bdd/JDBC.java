package bdd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import sosie_class.Stage;
import sosie_class.UniteEnseignementEntity;
import sosie_class.UserEntity;

public class JDBC {
private UserEntity Utilisateur;
private UserEntity Enseignant;
private Stage stage;
private UniteEnseignementEntity ue;

	
	public JDBC(){
		Utilisateur=new UserEntity();
		Enseignant=new UserEntity();
		stage=new Stage();
		ue=new UniteEnseignementEntity();
	}
	
	public boolean verifUser(int login,String mdp){
		boolean testRequete=false;
		try {
			 Class.forName("com.mysql.jdbc.Driver"); 
			 String url = "jdbc:mysql://localhost:3306/architecture";               
			 String user = "admin";
			 String passwd = "admin";
			 Connection conn = DriverManager.getConnection(url, user, passwd);
			
			Statement state = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);  //permet d'interagir avec la base de donn�es
		    ResultSet result = state.executeQuery("SELECT username, email, first_name, last_name,password,statut FROM user where username="+login+" and password='"+mdp+"'"); //resultat requete stock� dans un objet
		    //  ResultSetMetaData resultMeta = result.getMetaData();  //recuperation metaData
		      
		      if(result.next())
		      {
		    	 testRequete= true;
		      }
		      
		  } catch (Exception e) {
			    e.printStackTrace();
		  }  
		return testRequete;
	}
	
	public void newAccount(String firstName,String lastName,String mail,String statut,int login,String password) {
		try {
			 Class.forName("com.mysql.jdbc.Driver"); 
			 String url = "jdbc:mysql://localhost:3306/architecture";               
			 String user = "admin";
			 String passwd = "admin";
			 Connection conn = DriverManager.getConnection(url, user, passwd);
			
			Statement state = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);  //permet d'interagir avec la base de donn�es
			state.executeUpdate("insert into architecture.user (username, email, first_name, last_name,password,statut) values ("+login+",'"+mail+"','"+firstName+"','"+lastName+"','"+password+"','"+statut+"');"); //resultat requete stock� dans un objet
		   // ResultSet result = state.executeQuery("insert into table user values ("+login+",'"+mail+"','"+firstName+"','"+lastName+"','"+password+"','"+statut+"')"); //resultat requete stock� dans un objet
		    //  ResultSetMetaData resultMeta = result.getMetaData();  //recuperation metaData
		      
		      
		  } catch (Exception e) {
			  	System.out.println("\nErreur identifiant d�j� utilis�!!!\nFermeture du programme");
				System.exit(0);
		  }  
	}
	
	public UserEntity RecupInfoUser(int login,String mdp){
		try {
			 Class.forName("com.mysql.jdbc.Driver"); 
			 String url = "jdbc:mysql://localhost:3306/architecture";               
			 String user = "admin";
			 String passwd = "admin";
			 Connection conn = DriverManager.getConnection(url, user, passwd);
			
			Statement state = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);  //permet d'interagir avec la base de donn�es
		    ResultSet result = state.executeQuery("SELECT username, email, first_name, last_name,password,statut FROM user where username="+login+" and password='"+mdp+"'"); //resultat requete stock� dans un objet
		    //  ResultSetMetaData resultMeta = result.getMetaData();  //recuperation metaData
		      
		      if(result.next())
		      {
		    	 Utilisateur.setUsername(result.getInt("username"));
		    	 Utilisateur.setFirstName(result.getString("first_name"));
		    	 Utilisateur.setLastName(result.getString("last_name"));
		    	 Utilisateur.setMail(result.getString("email"));
		    	 Utilisateur.setStatut(result.getString("statut"));
		    	 Utilisateur.setPassword(result.getString("password"));
		      }
		      
		  } catch (Exception e) {
			    e.printStackTrace();
		  }  
		return Utilisateur;
	}
	
	public void modifInfoUser(int login,String firstName,String lastName,String mail,String statut,String password){
		try {
			//System.out.print(login+firstName+lastName+mail+statut+password);
			 Class.forName("com.mysql.jdbc.Driver"); 
			 String url = "jdbc:mysql://localhost:3306/architecture";               
			 String user = "admin";
			 String passwd = "admin";
			 Connection conn = DriverManager.getConnection(url, user, passwd);
			
			Statement state = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);  //permet d'interagir avec la base de donn�es
		    state.executeUpdate("update architecture.user set first_name='"+firstName+"',last_name='"+lastName+"',email='"+mail+"',statut='"+statut+"',password='"+password+"' where username="+login); //resultat requete stock� dans un objet
		    //  ResultSetMetaData resultMeta = result.getMetaData();  //recuperation metaData
		    
		  } catch (Exception e) {
			    e.printStackTrace();
		  }  
	}
	
	public void suppInfoUser(int login) {
		try {
			//System.out.print(login+firstName+lastName+mail+statut+password);
			 Class.forName("com.mysql.jdbc.Driver"); 
			 String url = "jdbc:mysql://localhost:3306/architecture";               
			 String user = "admin";
			 String passwd = "admin";
			 Connection conn = DriverManager.getConnection(url, user, passwd);
			
			Statement state = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);  //permet d'interagir avec la base de donn�es
		    state.executeUpdate("delete from user where username="+login); //resultat requete stock� dans un objet
		    //  ResultSetMetaData resultMeta = result.getMetaData();  //recuperation metaData
		   
		  } catch (Exception e) {
			  System.out.println("\nSuppression impossible: utilisateur est associ� � un stage!!");
		  }  
	}
	
	public boolean RechercheStageUser(int login){
		boolean testRequete=false;
		try {
			 Class.forName("com.mysql.jdbc.Driver"); 
			 String url = "jdbc:mysql://localhost:3306/architecture";               
			 String user = "admin";
			 String passwd = "admin";
			 Connection conn = DriverManager.getConnection(url, user, passwd);
			
			Statement state = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);  //permet d'interagir avec la base de donn�es
		    ResultSet result = state.executeQuery("SELECT eleve FROM stage where eleve="+login); //resultat requete stock� dans un objet
		    //  ResultSetMetaData resultMeta = result.getMetaData();  //recuperation metaData
		      
		      if(result.next())
		      {
		    	 testRequete= true;
		      }
		      
		  } catch (Exception e) {
			    e.printStackTrace();
		  }  
		return testRequete;
	}
	
	public Stage RecupInfoStage(int login){
		try {
			 Class.forName("com.mysql.jdbc.Driver"); 
			 String url = "jdbc:mysql://localhost:3306/architecture";               
			 String user = "admin";
			 String passwd = "admin";
			 Connection conn = DriverManager.getConnection(url, user, passwd);
			
			Statement state = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);  //permet d'interagir avec la base de donn�es
		    ResultSet result = state.executeQuery("SELECT id_stage, date_debut, date_fin, nom_entreprise,sujet,enseignant_referant FROM stage where eleve="+login); //resultat requete stock� dans un objet
		    //  ResultSetMetaData resultMeta = result.getMetaData();  //recuperation metaData
		      
		      if(result.next())
		      {
		    	 stage.setIdStage(result.getInt("id_stage"));
		    	 stage.setDateDebut(result.getDate("date_debut"));
		    	 stage.setDateFin(result.getDate("date_fin"));
		    	 stage.setNomEntreprise(result.getString("nom_entreprise"));
		    	 stage.setSujet(result.getString("sujet"));
		    	
		    	 Enseignant.setUsername(result.getInt("enseignant_referant"));
		    	 stage.setEnseignantReferant(Enseignant);
		      }
		      
		  } catch (Exception e) {
			    e.printStackTrace();
		  }  
		return stage;
	}
	
	public void modifInfoStage(long id_stage,Date date_debut,Date date_fin,String nom_entreprise,String sujet,int eleve,int enseignant_referant){
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		
		try {
			//System.out.print(login+firstName+lastName+mail+statut+password);
			 Class.forName("com.mysql.jdbc.Driver"); 
			 String url = "jdbc:mysql://localhost:3306/architecture";               
			 String user = "admin";
			 String passwd = "admin";
			 Connection conn = DriverManager.getConnection(url, user, passwd);
			
			Statement state = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);  //permet d'interagir avec la base de donn�es
		    state.executeUpdate("update architecture.stage set id_stage="+id_stage+" ,date_debut='"+format.format(date_debut)+"',date_fin='"+format.format(date_fin)+"',nom_entreprise='"+nom_entreprise+"',sujet='"+sujet+"',enseignant_referant="+enseignant_referant+" where eleve="+eleve); //resultat requete stock� dans un objet
		    //  ResultSetMetaData resultMeta = result.getMetaData();  //recuperation metaData
		    
		  } catch (Exception e) {
			  System.out.println("\nEnseignant non trouv�\n");
		  }  
	}
	
	public void newStage(String sujet,String nom_entreprise,String date_debut,String date_fin,int enseignant_referant,int eleve) {
		try {
			 Class.forName("com.mysql.jdbc.Driver"); 
			 String url = "jdbc:mysql://localhost:3306/architecture";               
			 String user = "admin";
			 String passwd = "admin";
			 Connection conn = DriverManager.getConnection(url, user, passwd);
			
			Statement state = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);  //permet d'interagir avec la base de donn�es
			state.executeUpdate("insert into architecture.stage (sujet, nom_entreprise, date_debut, date_fin,enseignant_referant,eleve) values ('"+sujet+"','"+nom_entreprise+"','"+date_debut+"','"+date_fin+"',"+enseignant_referant+","+eleve+");"); //resultat requete stock� dans un objet
		   // ResultSet result = state.executeQuery("insert into table user values ("+login+",'"+mail+"','"+firstName+"','"+lastName+"','"+password+"','"+statut+"')"); //resultat requete stock� dans un objet
		    //  ResultSetMetaData resultMeta = result.getMetaData();  //recuperation metaData
		      
		      
		  } catch (Exception e) {
			  	System.out.println("\nFormulaire incomplet!!!\nFermeture du programme");
				System.exit(0);
		  }  
	}

	public ResultSet RecupInfoue(){
		ResultSet bd = null;
		try {
			 Class.forName("com.mysql.jdbc.Driver"); 
			 String url = "jdbc:mysql://localhost:3306/architecture";               
			 String user = "admin";
			 String passwd = "admin";
			 Connection conn = DriverManager.getConnection(url, user, passwd);
			
			Statement state = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);  //permet d'interagir avec la base de donn�es
		    ResultSet result = state.executeQuery("SELECT ue.identifiant,ue.description,ue.nom,user.first_name,user.last_name FROM ue,user where user.username=ue.enseignant_responsable ;"); //resultat requete stock� dans un objet
		    //  ResultSetMetaData resultMeta = result.getMetaData();  //recuperation metaData
		    bd=result;    
		  } catch (Exception e) {
			    e.printStackTrace();
		  }  
		return bd;
	}
	
	public void suppUe(int id) {
		try {
			//System.out.print(login+firstName+lastName+mail+statut+password);
			 Class.forName("com.mysql.jdbc.Driver"); 
			 String url = "jdbc:mysql://localhost:3306/architecture";               
			 String user = "admin";
			 String passwd = "admin";
			 Connection conn = DriverManager.getConnection(url, user, passwd);
			
			Statement state = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);  //permet d'interagir avec la base de donn�es
		    state.executeUpdate("delete from ue where identifiant="+id); //resultat requete stock� dans un objet
		    //  ResultSetMetaData resultMeta = result.getMetaData();  //recuperation metaData
		   
		  } catch (Exception e) {
			  System.out.println("\nSuppression impossible!!");
		  }  
	}
	
	public boolean addUe(String description,String nom,String first_name,String last_name,int identifiant){
		boolean testRequete=false;
		int idUser=0;
		try {
			 Class.forName("com.mysql.jdbc.Driver"); 
			 String url = "jdbc:mysql://localhost:3306/architecture";               
			 String user = "admin";
			 String passwd = "admin";
			 Connection conn = DriverManager.getConnection(url, user, passwd);
			
			Statement state = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);  //permet d'interagir avec la base de donn�es
		    ResultSet result = state.executeQuery("SELECT username FROM user where first_name='"+first_name+"' and last_name='"+last_name+"' and statut='teacher'"); //resultat requete stock� dans un objet
		    
		    if(result.next())
		    {
		    	idUser=result.getInt("username"); 
		    	 testRequete=true;
		    }
		    
		    state.executeUpdate("insert into architecture.ue (identifiant, description, nom, enseignant_responsable) values ("+identifiant+",'"+description+"','"+nom+"',"+idUser+");");

		    
		  } catch (Exception e) {
			  System.out.println("\nEnseignant non reconnu ou formulaire incomplet!!");
			  testRequete=false;
		  }  
		return testRequete;
		}
	
	public int idUser(String first_name,String last_name){
		int idUser=0;
		try {
			 Class.forName("com.mysql.jdbc.Driver"); 
			 String url = "jdbc:mysql://localhost:3306/architecture";               
			 String user = "admin";
			 String passwd = "admin";
			 Connection conn = DriverManager.getConnection(url, user, passwd);
			
			Statement state = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);  //permet d'interagir avec la base de donn�es
		    ResultSet result = state.executeQuery("SELECT username FROM user where first_name='"+first_name+"' and last_name='"+last_name+"' and statut='teacher'"); //resultat requete stock� dans un objet
		    
		    if(result.next())
		    {
		    	idUser=result.getInt("username"); 
		    }
		    
		  } catch (Exception e) {
			  System.out.println("\nEnseignant non reconnu ou formulaire incomplet!!");
			  return -1;
		  }  
		return idUser;
		}
	
	public void modifInfoStage1(String attribut,String valeur,int id){
		try {
			//System.out.print(login+firstName+lastName+mail+statut+password);
			 Class.forName("com.mysql.jdbc.Driver"); 
			 String url = "jdbc:mysql://localhost:3306/architecture";               
			 String user = "admin";
			 String passwd = "admin";
			 Connection conn = DriverManager.getConnection(url, user, passwd);
			
			Statement state = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);  //permet d'interagir avec la base de donn�es
		    state.executeUpdate("update architecture.ue set "+attribut+"='"+valeur+"' where identifiant="+id); //resultat requete stock� dans un objet
		    //  ResultSetMetaData resultMeta = result.getMetaData();  //recuperation metaData
		    
		  } catch (Exception e) {
			  System.out.println("\nLa modification a echou�e\n");
		  }  
	}
	public void modifInfoStage2(String attribut,int valeur,int id){
		try {
			//System.out.print(login+firstName+lastName+mail+statut+password);
			 Class.forName("com.mysql.jdbc.Driver"); 
			 String url = "jdbc:mysql://localhost:3306/architecture";               
			 String user = "admin";
			 String passwd = "admin";
			 Connection conn = DriverManager.getConnection(url, user, passwd);
			
			Statement state = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);  //permet d'interagir avec la base de donn�es
		    state.executeUpdate("update architecture.ue set "+attribut+"="+valeur+" where identifiant="+id); //resultat requete stock� dans un objet
		    //  ResultSetMetaData resultMeta = result.getMetaData();  //recuperation metaData
		    
		  } catch (Exception e) {
			  System.out.println("\nLa modification a echou�e\n");
		  }  
	}
}

