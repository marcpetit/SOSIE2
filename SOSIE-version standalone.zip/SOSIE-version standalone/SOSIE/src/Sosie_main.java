
import view.vue_sosie;

public class Sosie_main {

	public static void main(String[] args) {
		
		vue_sosie Programme=new vue_sosie();
		Programme.controlleur("home");
	}

}
