package com.arlo.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArloRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArloRestApplication.class, args);
	}
}
