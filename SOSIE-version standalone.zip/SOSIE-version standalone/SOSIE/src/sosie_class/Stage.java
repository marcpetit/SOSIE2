package sosie_class;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Stage {
	private long idStage;
	private String sujet;
	private Date dateDebut;
	private Date dateFin;
	private String nomEntreprise;
	private UserEntity eleve;
	private UserEntity enseignantReferant;
	
	public String getNomEntreprise() {
		return nomEntreprise;
	}

	/**
	 * @param nomEntreprise the nomEntreprise to set
	 */
	public void setNomEntreprise(String nomEntreprise) {
		this.nomEntreprise = nomEntreprise;
	}

	/**
	 * @return the eleve
	 */
	public UserEntity getEleve() {
		return eleve;
	}

	/**
	 * @param eleve the eleve to set
	 */
	public void setEleve(UserEntity eleve) {
		this.eleve = eleve;
	}

	/**
	 * @return the enseignantReferant
	 */
	public UserEntity getEnseignantReferant() {
		return enseignantReferant;
	}

	/**
	 * @param enseignantReferant the enseignantReferant to set
	 */
	public void setEnseignantReferant(UserEntity enseignantReferant) {
		this.enseignantReferant = enseignantReferant;
	}

	/**
	 * @return the idStage
	 */
	public long getIdStage() {
		return idStage;
	}

	/**
	 * @param idStage
	 *            the idStage to set
	 */
	public void setIdStage(long idStage) {
		this.idStage = idStage;
	}

	/**
	 * @return the sujet
	 */
	public String getSujet() {
		return sujet;
	}

	/**
	 * @param sujet
	 *            the sujet to set
	 */
	public void setSujet(String sujet) {
		this.sujet = sujet;
	}

	/**
	 * @return the dateDebut
	 */
	public Date getDateDebut() {
		return dateDebut;
	}

	/**
	 * @param saisie4
	 *            the dateDebut to set
	 */
	public void setDateDebut(Date saisie4) {
		this.dateDebut = saisie4;
	}

	/**
	 * @return the dateFin
	 */
	public Date getDateFin() {
		return dateFin;
	}

	/**
	 * @param dateFin
	 *            the dateFin to set
	 */
	public void setDateFin(Date dateFin) {
		this.dateFin = dateFin;
	}

}
