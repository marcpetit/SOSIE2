#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#define TAILLEMDP 8

void mot_minuscule(char* mot,char* mot2){
    int i;
    for (i=0; i<strlen(mot); i++) {
        mot2[i]=mot[i];
        mot[i]=tolower(mot[i]);
        if(mot[i]==' '){
            mot[i]='_';
        }
        if(mot[i]=='\''){
            mot[i]='_';
        }
    }
    mot2[i]='\0';
}

void toupper_premier_caractere(char* mot){
    mot[0]=toupper(mot[0]);
    int i;
    for (i=0; i<strlen(mot); i++) {
        if(mot[i]==' '){
            mot[i]='_';
        }
        if(mot[i]=='\''){
            mot[i]='_';
        }
    }
}

void supprime_last_carac(char* mot){
    if(mot[strlen(mot)-2]==' ')
    {
        mot[strlen(mot)-2]='\0';
    }

    if(mot[strlen(mot)-1]==' ')
    {
        mot[strlen(mot)-1]='\0';
    }

    int i;
    for (i=0; i<strlen(mot); i++) {
        if(mot[i]==' '){
            mot[i]='_';
        }
        if(mot[i]=='\''){
            mot[i]='_';
        }
    }
}

int random(int nombre){
    int var;
    var=(rand()%(nombre))+1;
    return var;
}

void mot_de_passe(unsigned char* ar){
    int i;

    //srand((unsigned)time(NULL));
    for(i=0;i<TAILLEMDP;i++)
    {
       ar[i] = 'a'+rand()%26;
      //ar[i]=tolower(ar[i]);
    }
    ar[i]='\0';
    //printf("caract�re %s\n",ar);
}

void fonction_AlimenterBD_IATIC5(){
    //srand(time(NULL));
    char prenom[50];
    char prenom2[50];
    char nom[50];
    char nom2[50];
    int id=1;
    unsigned char ar[TAILLEMDP+1];
    FILE* fichier=NULL;
    fichier=fopen("listes/liste_IATIC5.txt","r");

    if (fichier == NULL)
    {
        printf("Impossible d'ouvrir le fichier listes/liste_IATIC5.txt\n\n");
    }

    else{
        FILE* fichier2=NULL;
        fichier2=fopen("listes/liste_IATIC5.sql","w");

        while (fscanf(fichier, "%s %s", nom, prenom) != EOF)
        {
            mot_de_passe(ar);
            mot_minuscule(nom,nom2);
            mot_minuscule(prenom,prenom2);
            fprintf(fichier2,"INSERT INTO `architecture`.`user` (`username`, `email`, `first_name`, `last_name`, `password`, `statut`) VALUES ('%d', '%s%s@sosie.fr', '%s', '%s', '%s', 'Student'); \n",id,prenom, nom,prenom2,nom2,ar);
            id++;
        }
        fclose(fichier2);
        fclose(fichier);
        printf("Operation effectuee avec succes! Fichier SQL liste_IATIC5.sql genere!\n\n");
    }

}

void fonction_AlimenterBD_random(){
    //srand(time(NULL));
    char prenom[50];
    char prenom2[50];
    char nom[50];
    char nom2[50];
    int id=37;
    int i=0;
    int j=0;
    int cmp=0;
    int cmp2=0;
    int curseur1=0;
    int curseur2=0;
    int eleve=0;
    int enseignant=0;
    int administratif=0;
    unsigned char ar[TAILLEMDP+1];
    FILE* fichier=NULL;
    FILE* fichier1=NULL;
    fichier=fopen("listes/liste_Nom.txt","r");
    fichier1=fopen("listes/liste_Prenom.txt","r");

    if ((fichier == NULL) || (fichier1 == NULL)){
        printf("Impossible d'ouvrir le fichier listes/liste_Nom.txt ou listes/liste_Prenom.txt \n\n");
    }
    else{
        FILE* fichier2=NULL;
        fichier2=fopen("listes/autre_liste.sql","w");

        while (fgets(nom, 100, fichier) != NULL){
            cmp++;
        }
        while (fgets(prenom, 100, fichier1) != NULL){
            cmp2++;
        }

        printf("\nDeterminez un nombre d'eleves, enseignants et administratifs!\n\n");
        do{
        printf("Nombre d'eleves:");
        scanf("%d",&eleve);
        }while(!(eleve>=0 && eleve<=1000000000));
        do{
        printf("Nombre d'enseignants:");
        scanf("%d",&enseignant);
        }while(!(enseignant>=0 && enseignant<=1000000000));
        do{
        printf("Nombre d'administratifs:");
        scanf("%d",&administratif);
        }while(!(administratif>=0 && administratif<=1000000000));

        while(eleve>0){
            curseur1=random(cmp);
            curseur2=random(cmp2);
            //printf("%d %d\n",curseur1,curseur2);
            rewind(fichier);
            rewind(fichier1);
            i=0;
            j=0;
            while(i<curseur1){
                fgets(nom, 100, fichier);
                i++;
            }
            while(j<curseur2){
                //fgets(prenom, 100, fichier1);
                fscanf(fichier1,"%s",prenom);
                j++;
            }
            supprime_last_carac(nom);
            toupper_premier_caractere(prenom);
            //printf("%s %s\n",nom,prenom);
            mot_de_passe(ar);
            mot_minuscule(nom,nom2);
            mot_minuscule(prenom,prenom2);

            fprintf(fichier2,"INSERT INTO `architecture`.`user` (`username`, `email`, `first_name`, `last_name`, `password`, `statut`) VALUES ('%d', '%s%s@sosie.fr', '%s', '%s', '%s', 'Student'); \n",id, prenom,nom,prenom2,nom2,ar);
            id++;
            eleve--;
        }

        while(enseignant>0){
            curseur1=random(cmp);
            curseur2=random(cmp2);
            //printf("%d %d\n",curseur1,curseur2);
            rewind(fichier);
            rewind(fichier1);
            i=0;
            j=0;
            while(i<curseur1){
                fgets(nom, 100, fichier);
                i++;
            }
            while(j<curseur2){
                //fgets(prenom, 100, fichier1);
                fscanf(fichier1,"%s",prenom);
                j++;
            }
            supprime_last_carac(nom);
            toupper_premier_caractere(prenom);
            //printf("%s %s\n",nom,prenom);
            mot_de_passe(ar);
            mot_minuscule(nom,nom2);
            mot_minuscule(prenom,prenom2);

            fprintf(fichier2,"INSERT INTO `architecture`.`user` (`username`, `email`, `first_name`, `last_name`, `password`, `statut`) VALUES ('%d', '%s%s@sosie.fr', '%s', '%s', '%s', 'teacher'); \n",id, prenom,nom,prenom2,nom2,ar);
            id++;
            enseignant--;
        }
        while(administratif>0){
            curseur1=random(cmp);
            curseur2=random(cmp2);
            //printf("%d %d\n",curseur1,curseur2);
            rewind(fichier);
            rewind(fichier1);
            i=0;
            j=0;
            while(i<curseur1){
                fgets(nom, 100, fichier);
                i++;
            }
            while(j<curseur2){
                //fgets(prenom, 100, fichier1);
                fscanf(fichier1,"%s",prenom);
                j++;
            }
            supprime_last_carac(nom);
            toupper_premier_caractere(prenom);
            //printf("%s %s\n",nom,prenom);
            mot_de_passe(ar);
            mot_minuscule(nom,nom2);
            mot_minuscule(prenom,prenom2);

            fprintf(fichier2,"INSERT INTO `architecture`.`user` (`username`, `email`, `first_name`, `last_name`, `password`, `statut`) VALUES ('%d', '%s%s@sosie.fr', '%s', '%s', '%s', 'Administrator'); \n",id, prenom, nom,prenom2,nom2,ar);
            id++;
            administratif--;
        }

        fclose(fichier);
        fclose(fichier1);
        fclose(fichier2);
        printf("Operation effectuee avec succes! Fichier SQL autre_liste.sql genere!\n\n");
    }
}

int main()
{
    srand(time(NULL));
    int choix=0;
    printf("Bienvenue dans le programme d'alimentation de la base de donnees!\n\n\n");
    printf("Action 1 (touche 1): Alimenter automatiquement la base de donnees avec la liste des eleves de votre promotion.\n\n");
    printf("Action 2 (touche 2): Alimenter automatiquement la base de donnees avec un nombre determines d'eleves, enseignants et administratifs dont les noms sont crees aleatoirement a partir d'une liste.\n\n");
    printf("Action 3 (touche 3): Action 1 puis Action 2\n\ntouche:");

    scanf("%d",&choix);

    if(choix==1){
        fonction_AlimenterBD_IATIC5();
    }
    else if(choix==2){
        fonction_AlimenterBD_random();
    }
    else if(choix==3){
        fonction_AlimenterBD_IATIC5();
        fonction_AlimenterBD_random();
    }
    else{
        printf("Le programme va s'arreter suite a une erreur de saisie!\n\n");
    }

    system("pause");
    return 0;
}
