package sosie_class;

import java.io.Serializable;

public class UniteEnseignementEntity implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String identifiant;
    private String nom;
	private UserEntity enseignantResponsable;
    private String description;

	public UniteEnseignementEntity(String identifiant, String nom, UserEntity enseignantResponsable,
			String description) {
		super();
		this.identifiant = identifiant;
		this.nom = nom;
		this.enseignantResponsable = enseignantResponsable;
		this.description = description;
	}

	public UniteEnseignementEntity() {
		super();
	}



	public String getIdentifiant() {
		return identifiant;
	}

	public void setIdentifiant(String identifiant) {
		this.identifiant = identifiant;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public UserEntity getEnseignantResponsable() {
		return enseignantResponsable;
	}

	public void setEnseignantResponsable(UserEntity enseignantResponsable) {
		this.enseignantResponsable = enseignantResponsable;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "UniteEnseignementEntity [identifiant=" + identifiant + ", nom=" + nom + ", enseignantResponsable="
				+ enseignantResponsable + ", description=" + description + "]";
	}
	
}
